<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommentSales extends Model
{
    protected $fillable = [ 'sale_id', 'comentario'];
}
