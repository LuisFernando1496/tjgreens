<?php $__env->startSection('content'); ?>
<div class="container">    
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <?php echo e($error); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

        <table class="display table table-striped table-bordered" id="example" style="width:100%">
            <thead class="black white-text">
                <tr>
                    <th scope="col">Cliente</th>
                    <th scope="col">Total</th>
                    <th scope="col">Abonos</th>
                    
                   
                    <th scope="col">Restante</th>
                    <th scope="col">Fecha</th>
                    <th scope="col">Estatus</th>                
           
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody id="mydata">
                <?php $__currentLoopData = $credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total = 0;
                        $restante = $item->cart_total;
                    ?>
                <tr>
                    <th scope="row"><?php echo e($item->client->name); ?></th>
                    <th>$<?php echo e($item->cart_total); ?></th>
                    <td>
                        <?php $__currentLoopData = $item->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $total += $item2->deposit;
                                $restante=$item->cart_total-$total;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        $<?php echo e($total); ?>.00
                    </td>
                    <td>$<?php echo e($restante); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                    <?php if($item->status_credit=='adeudo'): ?>
                    <td><div class="card" style="text-align:center; background-color:red">
                    <label style="color:white" for="status" ><?php echo e($item->status_credit); ?></label>
                    </div>
                    </td>
                    <?php else: ?>
                    <td><div class="card" style="text-align:center; background-color:green">
                    <label style="color:white" for="status" ><?php echo e($item->status_credit); ?></label>
                    </div>
                    </td>
                    <?php endif; ?>
                    <td>                   
                        <div class="row">
                        <?php if(Auth::user()->rol_id == 1): ?>

                                    <form onsubmit="return confirm('Cancelar esta venta?')" action="/sale/<?php echo e($item->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-outline-danger btn-sm  mx-2" data-type="delete">
                                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5a.5.5 0 0 0-1 0v7a.5.5 0 0 0 1 0v-7z"/>
                                            </svg>   
                                            <small>CANCELAR</small>
                                        </button> 
                                    </form>
                                <?php endif; ?>
                        </div>                                                                     
                    </td>
                    <td>
                    <a href="<?php echo e(asset('sale-detail-history/'.$item->id.'')); ?>" class="btn btn-primary btn-sm mx-2"><small>DETALLES</small></a>
                    </td>
                </tr>
        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>   
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\insadminv2-tjgreen\resources\views/client/credit.blade.php ENDPATH**/ ?>