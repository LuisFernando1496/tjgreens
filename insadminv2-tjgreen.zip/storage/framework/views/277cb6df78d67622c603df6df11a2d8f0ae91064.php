<html>
    <head>
        <style type="text/css">
            table {
                border-collapse: collapse;
            }

            table, th, td {
                border: 1px solid black;
                text-align: center;
                border-color: #424242;
            }
            .backgroundColor{
                background: red;
            }
        </style>
    </head> 
    <body>
      <?php
          $cantidadProduct = 0;
      ?>
        
            <h4 >REPORTE DE INVENTARIO</h4>
            <table style="width: 100%; margin-top:20px;">
                <?php if(Auth::user()->rol_id == 1): ?>
                    <tr>
                        <th colspan="5" class="backgroundColor">
                            SUCURSAL
                        </th>
                    </tr>
                    <tr>
                        <td colspan="5">
                            <?php echo e($branchOffice->name); ?>

                        </td>
                    </tr>
                    <?php else: ?>
                    <tr>
                        <th colspan="4" class="backgroundColor">
                            SUCURSAL
                        </th>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <?php echo e($branchOffice->name); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th class="backgroundColor">PRODUCTO</th>
                    <th class="backgroundColor">CATEGORÍA</th>
                    <th class="backgroundColor">MARCA</th>
                    <th class="backgroundColor">CANTIDAD</th>
                    <?php if(Auth::user()->rol_id == 1): ?>
                    <th class="backgroundColor">COSTO</th>
                    <?php endif; ?>
                </tr>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($branchOffice->id == $p->branch_office_id ): ?>
                        <?php
                        $cantidadProduct ++;
                    ?>
                <tr>
                    
                    <td><?php echo e($p->name); ?></td>
                    <td><?php echo e($p->category->name); ?></td>

                    <?php if($p->brand == null): ?>
                    <td>N/A</td>
                    <?php else: ?>
                    <td><?php echo e($p->brand->name); ?></td>
                    <?php endif; ?>

                    <?php if($p->stock == null): ?>
                    <td>N/A</td>
                    <?php else: ?>
                    <td><?php echo e($p->stock); ?></td> 
                    <?php endif; ?>
                    <?php if(Auth::user()->rol_id == 1): ?>
                    <td>$<?php echo e($p->cost); ?></td>
                    <?php endif; ?>
                    

                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>


            <h5 style="margin: 5px;">Total de productos: <?php echo e($cantidadProduct); ?></h5>
            <h5 style="margin: 20px;">REPORTE GENERADO POR <?php echo e(strtoupper($user->name)); ?></h5>
            <h5 style="margin: 5px;"><?php echo e($date); ?></h5>
            
    
    </body>
</html><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\insadminv2-tjgreen\resources\views/reports/reportInventByBranchOfficeId.blade.php ENDPATH**/ ?>