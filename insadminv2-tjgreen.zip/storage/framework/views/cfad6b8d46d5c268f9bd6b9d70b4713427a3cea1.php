<html>
    <head>
        <style type="text/css">
            table {
                border-collapse: collapse;
            }

            table, th, td {
                border: 1px solid black;
                text-align: center;
                border-color: #424242;
                font-size: 12px;
            }
            .backgroundColor{
                background: red;
            }
        </style>
    </head> 
    <body>
        <div style="text-align:center; margin-left: auto; margin-right: auto;">


            <?php
            $totals = 0;
            $counterProduct = 1;
        ?>
<h5>TRANSFER</h5>
            <table style="width: 100%; margin-top:20px;">
        
                    
                <tr>
                    <th colspan="5" >
                      Origin <?php echo e($send[0]->trasnfer->origin->name); ?>

                    </th>
                </tr>
                <tr>
                    <th style="font-size: 10px"  colspan="5" >submitted to  <?php echo e($send[0]->trasnfer->branchOffice->name); ?> </th>
                  
                </tr>
                <tr>
                    <th style="font-size: 10px"  colspan="5" >Fecha <?php echo e($send[0]->trasnfer->created_at->format('d-m-y')); ?> </th>
                  
                </tr>
                <tr>
                    <th style="font-size: 10px" class="backgroundColor">#</th>
                    <th style="font-size: 10px" class="backgroundColor">MARCA</th>
                    <th style="font-size: 10px" class="backgroundColor">DESCRIPTION</th>
                    <th style="font-size: 10px" class="backgroundColor">QTY</th>
                    <th style="font-size: 10px" class="backgroundColor">UNIT COST</th>
                    <th style="font-size: 10px" class="backgroundColor">COSTO TOTAL USD</th>
                    <th style="font-size: 10px" class="backgroundColor">SELL RETAIL PRICE</th>
                    <th style="font-size: 10px" class="backgroundColor">TOTAL PRICE</th>
                  
                </tr>
                
               <?php $__currentLoopData = $send; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                        <td><?php echo e($counterProduct); ?></td>
                       <td><?php echo e($item->product->brand->name); ?></td>
                       <td><?php echo e($item->product->name); ?></td>
                       <td><?php echo e($item->quantity); ?></td>
                       <?php if($item->cost != 0): ?>
                            <td><?php echo e($item->cost); ?></td>
                        <td><?php echo e($item->cost * $item->quantity); ?></td>
                     
                           
                       <?php else: ?>
                            <td><?php echo e($item->product->cost); ?></td>
                            <td><?php echo e($item->product->cost * $item->quantity); ?></td>
                   
                       <?php endif; ?>
                      
                       <td>$<?php echo e($item->sale_price); ?></td>
                       <td>$<?php echo e($item->total); ?></td>
                       <?php
                           $totals += $item->total;
                           $counterProduct++
                       ?>
                    
                   </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <tr>
                 <th colspan="6"></th>
                 <td>Total: $<?php echo e($totals); ?></td>
             </tr>
            </table>




           
            
        </div>
    </body>
</html><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\insadminv2-tjgreen\resources\views/reports/traspacing.blade.php ENDPATH**/ ?>