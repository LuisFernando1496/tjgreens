<html>
    <head>
        <style type="text/css">
            table {
                border-collapse: collapse;
            }

            table, th, td {
                border: 1px solid black;
                text-align: center;
                border-color: #424242;
                font-size: 12px;
            }
            .backgroundColor{
                background: red;
            }
        </style>
    </head> 
    <body>
        <div style="text-align:center; margin-left: auto; margin-right: auto;">

<?php
    $totalUsd = 0;
    $totalMxn = 0;
?>
            <h4 >REPORTE DE COMPRAS</h4>
            <h5>DESDE <?php echo e($from); ?>-- HASTA <?php echo e($to); ?></h5>
          
            <table style="width: 100%; margin-top:20px;">
              
                    
                <tr>
                    <th colspan="7" class="backgroundColor">
                   <?php echo e($compras[0]->name_office); ?>

                    </th>
                </tr>
                <tr>
                    <td colspan="7">
                      Productos
                    </td>
                </tr>
             
                    

                <tr>
                    <th scope="col"  class="backgroundColor">Nombre</th>
                    <th scope="col"  class="backgroundColor">Categoria</th>
                    <th scope="col"  class="backgroundColor">Costo pza (MXN)</th>
                    <th scope="col"  class="backgroundColor">Costo pza (USD)</th>
                    <th scope="col"  class="backgroundColor">Cantidad</th>
                    <th scope="col"  class="backgroundColor">Total (MXN)</th>
                    <th scope="col"  class="backgroundColor">Total (USD)</th>
                   
                </tr>
               <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <tr>
                    
                    <th scope="row"><?php echo e($compra->product->name); ?></th>
                  <th scope="row"><?php echo e($compra->product->category->name); ?></th>
                    <th scope="row">$<?php echo e($compra->product->cost); ?></th>
                    <th scope="row">$<?php echo e(number_format(($compra->product->cost /20.68),2)); ?></th>
                    <th scope="row"><?php echo e($compra->quantity); ?></th>
                    <th scope="row">$<?php echo e($compra->total); ?> </th>
                    <th scope="row">$<?php echo e(number_format(($compra->total/20.68),2)); ?> </th>

                </tr>
           <?php
               $totalUsd += ($compra->total/20.68);
               $totalMxn += $compra->total;
           ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

       
            <table style="width: 100%; margin-top:20px;">
                
          
                <tr>
                    <th>TOTAL COMPRAS (MXN)</th>
                    <td colspan="3">$<?php echo e($totalMxn); ?></td>
                    

                </tr>
              
                <tr>
                    <th>TOTAL COMPRAS (USD)</th>
                    <td colspan="3">$<?php echo e(number_format($totalUsd,2)); ?></td>
                </tr>
              

             
            </table>


        
            
        </div>
    </body>
</html><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\insadminv2-tjgreen\resources\views/reports/reportPurchases.blade.php ENDPATH**/ ?>