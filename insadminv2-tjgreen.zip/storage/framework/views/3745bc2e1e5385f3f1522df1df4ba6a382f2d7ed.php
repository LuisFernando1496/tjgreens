

<?php $__env->startSection('content'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


    <?php if(Auth::user()->rol_id == 1): ?>
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col">
                            <h4 class="card-title">Almacenes</h4>
                        </div>
                        <div class="col-sm-4">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                Crear
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="container">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Oficina</th>
                                    <th>Encargado</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $almacenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($almacen->id); ?></td>
                                        <td><?php echo e($almacen->oficina->name); ?></td>
                                        <td><?php echo e($almacen->user->name); ?> <?php echo e($almacen->user->last_name); ?></td>
                                        <?php if($almacen->status == true): ?>
                                            <td style="color: rgb(5, 182, 5)">Activo</td>
                                        <?php else: ?>
                                            <td style="color: red">Inactivo</td>
                                        <?php endif; ?>
                                        <td>
                                            <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($almacen->id); ?>"><i class="bi bi-pencil"></i></button>
                                            <?php if($almacen->status == true): ?>
                                                <form action="<?php echo e(route('almacen.status',$almacen->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-outline-success"><i class="bi bi-toggle-on"></i></button>
                                                </form>
                                            <?php else: ?>
                                                <form action="<?php echo e(route('almacen.status',$almacen->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-outline-danger"><i class="bi bi-toggle-off"></i></button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <div class="modal fade" id="exampleModal<?php echo e($almacen->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('almacen.update',$almacen)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Editar almacén #<?php echo e($almacen->id); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col">
                                                                <label for="">Usuario</label>
                                                                <select name="user_id" id="user_id" required class="form-control">
                                                                    <option value="">--Seleccionar--</option>
                                                                    <?php $__empty_2 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                        <?php if($user->id == $almacen->user_id): ?>
                                                                            <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></option>
                                                                        <?php else: ?>
                                                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></option>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                        <option>Sin usuarios registrados</option>
                                                                    <?php endif; ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                        <p><b>**Nota**</b> El usuario previamente creado y asignado al almacén ya podrá ingresar al sistema y administrar el mismo.</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <button type="submit" class="btn btn-primary">Guardar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td style="align-content: center" colspan="5">Esta sucursal no cuenta con almacén</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($almacenes->links()); ?>

                    </div>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<?php echo e(route('almacen.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Crear almacén</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p style="color: red">El siguiente formulario es para crear el almacén virtual y asignar al responsable del mismo.</p>
                            <div class="row">
                                <div class="col">
                                    <label for="">Usuario</label>
                                    <select name="user_id" id="user_id" required class="form-control">
                                        <option value="">--Seleccionar--</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <option>Sin usuarios registrados</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <hr>
                            <p><b>**Nota**</b> El usuario previamente creado y asignado al almacén ya podrá ingresar al sistema y administrar el mismo.</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Crear</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col">
                            <h4 class="card-title">Almacén</h4>
                        </div>
                        <div class="col-2">
                            <button class="btn btn-outline-primary" type="button" data-bs-toggle="modal" data-bs-target="#inventarioModal">Agregar</button>
                        </div>
                        <div class="col-2">
                            <?php
                                $enum = 0;
                                $enum = sizeof($carritoCompras);
                            ?>
                            <button class="btn btn-outline-success" type="button" data-bs-toggle="modal" data-bs-target="#carritoCompraModal">Comprar +<?php echo e($enum); ?></button>
                        </div>
                        <div class="col-2">
                            <?php
                                $num = 0;
                                $num = sizeof($carrito);
                            ?>
                            <button class="btn btn-outline-secondary" type="button" data-bs-toggle="modal" data-bs-target="#carritoModal">Vender +<?php echo e($num); ?></button>
                        </div>
                        <div class="col-2">
                            <a href="<?php echo e(route('getOrder')); ?>" target="blank" type="button" class="btn btn-outline-warning"><i class="bi bi-receipt-cutoff">Orden</i></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="container">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Código</th>
                                    <th>Nombre</th>
                                    <th>Categoria</th>
                                    <th>Marca</th>
                                    <th>Stock</th>
                                    <th>Precio</th>
                                    <th>Costo</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $inventarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($inventario->id); ?></td>
                                        <td><?php echo e($inventario->bar_code); ?></td>
                                        <td><?php echo e($inventario->name); ?></td>
                                        <td><?php echo e($inventario->categoria->name); ?></td>
                                        <td><?php echo e($inventario->marca->name); ?></td>
                                        <td><?php echo e($inventario->stock); ?></td>
                                        <td>$<?php echo e($inventario->price); ?></td>
                                        <td>$<?php echo e($inventario->cost); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#addInventario<?php echo e($inventario->id); ?>"><i class="bi bi-bag-plus-fill"></i></button>
                                            <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#addCompra<?php echo e($inventario->id); ?>"><i class="bi bi-bag-plus"></i></button>
                                        </td>
                                    </tr>

                                    <div class="modal fade" id="addInventario<?php echo e($inventario->id); ?>" tabindex="-1" aria-labelledby="addInventario<?php echo e($inventario->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('add',$inventario->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Añadir al carrito</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col">
                                                                <label for="">Producto</label>
                                                                <input type="text" required readonly value="<?php echo e($inventario->name); ?>" class="form-control">
                                                            </div>
                                                            <div class="col">
                                                                <label for="">Precio</label>
                                                                <input type="number" class="form-control" step="any" required readonly value="<?php echo e($inventario->price); ?>" id="price<?php echo e($inventario->id); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label for="">Cantidad</label>
                                                                <input name="quantity" type="number" class="form-control cantidad" required data-id="<?php echo e($inventario->id); ?>" min="1" max="<?php echo e($inventario->stock); ?>" value="1">
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <label for="">Sub Total</label>
                                                                <input type="number" class="form-control" step="any" id="subtotal<?php echo e($inventario->id); ?>" value="<?php echo e($inventario->price); ?>" readonly name="subtotal">
                                                            </div>
                                                            <div class="col">
                                                                <label for="">Descuento en %</label>
                                                                <input name="discount" type="number" data-id="<?php echo e($inventario->id); ?>" class="form-control descuento" step="any" id="descuento<?php echo e($inventario->id); ?>" value="0" min="0">
                                                            </div>
                                                            <div class="col">
                                                                <label for="">Total</label>
                                                                <input name="total" type="number" step="any" class="form-control" id="total<?php echo e($inventario->id); ?>" value="<?php echo e($inventario->price); ?>" readonly>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <button type="submit" class="btn btn-primary">Agregar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="modal fade" id="addCompra<?php echo e($inventario->id); ?>" tabindex="-1" aria-labelledby="addInventario<?php echo e($inventario->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('addCompra',$inventario->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Añadir al carrito</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col">
                                                                <label for="">Producto</label>
                                                                <input type="text" required readonly value="<?php echo e($inventario->name); ?>" class="form-control">
                                                            </div>
                                                            <div class="col">
                                                                <label for="">Costo</label>
                                                                <input type="number" class="form-control" step="any" required readonly value="<?php echo e($inventario->cost); ?>" id="cost<?php echo e($inventario->id); ?>">
                                                            </div>
                                                            <div class="col">
                                                                <label for="">Cantidad</label>
                                                                <input name="quantity" type="number" class="form-control cantidadCompra" required data-id="<?php echo e($inventario->id); ?>" min="1" max="<?php echo e($inventario->stock); ?>" value="1">
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <label for="">Sub Total</label>
                                                                <input type="number" class="form-control" step="any" id="subtotalCompra<?php echo e($inventario->id); ?>" value="<?php echo e($inventario->cost); ?>" readonly name="subtotal">
                                                            </div>
                                                            <div class="col">
                                                                <label for="">Descuento en %</label>
                                                                <input name="discount" type="number" data-id="<?php echo e($inventario->id); ?>" class="form-control descuentoCompra" step="any" id="descuentoCompra<?php echo e($inventario->id); ?>" value="0" min="0">
                                                            </div>
                                                            <div class="col">
                                                                <label for="">Total</label>
                                                                <input name="total" type="number" step="any" class="form-control" id="totalCompra<?php echo e($inventario->id); ?>" value="<?php echo e($inventario->cost); ?>" readonly>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <button type="submit" class="btn btn-primary">Agregar</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="inventarioModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<?php echo e(route('inventario.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Agregar Producto</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col">
                                    <label for="">Código</label>
                                    <input type="text" class="form-control" required name="bar_code">
                                </div>
                                <div class="col">
                                    <label for="">Nombre</label>
                                    <input type="text" class="form-control" required name="name">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <label for="">Stock</label>
                                    <input type="number" class="form-control" required name="stock">
                                </div>
                                <div class="col">
                                    <label for="">Costo</label>
                                    <input type="number" step="any" class="form-control" required name="cost">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <label for="">Precio</label>
                                    <input type="numer" step="any" class="form-control" required name="price">
                                </div>
                                <div class="col">
                                    <label for="">Marca</label>
                                    <select name="brand_id" id="" required class="form-control">
                                        <option value="">--Seleccionar--</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col">
                                    <label for="">Categoria</label>
                                    <select name="category_id" id="category_id" class="form-control" required>
                                        <option value="">--Seleccionar--</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Agregar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="carritoModal" tabindex="-1" aria-labelledby="addInventario" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<?php echo e(route('concluir')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">Carrito</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Producto</th>
                                            <th>Precio</th>
                                            <th>Cantidad</th>
                                            <th>Sub Total</th>
                                            <th>Descuento %</th>
                                            <th>Total</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tablita">
                                        <?php
                                            $total = 0;
                                        ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->inventario[0]->name ?? ""); ?></td>
                                                <td>$<?php echo e($item->inventario[0]->price ?? 0); ?></td>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td>$<?php echo e($item->subtotal); ?></td>
                                                <td><?php echo e($item->discount); ?>%</td>
                                                <td>$<?php echo e($item->total); ?></td>
                                                <td>
                                                    <button class="btn btn-outline-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                                                </td>
                                            </tr>
                                            <?php
                                                $total += $item->total;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="container">
                                <div class="row">
                                    <div class="col">
                                        <label for="">Sucursal</label>
                                        <select name="office_id" id="" class="form-control" required>
                                            <option value="">--Seleccionar--</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $oficinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oficina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php if($oficina->id == Auth::user()->branch_office_id): ?>
                                                    <option selected value="<?php echo e($oficina->id); ?>"><?php echo e($oficina->name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($oficina->id); ?>"><?php echo e($oficina->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <label for="">Tipo Pago</label>
                                        <select name="type" id="type" class="form-control" required>
                                            <option value="">--Seleccionar--</option>
                                            <option value="Efectivo">Efectivo</option>
                                            <option value="Tarjeta">Tarjeta</option>
                                            <option value="Transferencia">Transferencia</option>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <label for="">Sub Total</label>
                                        <input type="number" name="subtotal" class="form-control" step="any" id="subtotalGeneral" readonly value="<?php echo e($total); ?>">
                                    </div>
                                    <div class="col">
                                        <label for="">Descuento %</label>
                                        <input type="number" name="discount" value="0" min="0" class="form-control" step="any" max="100" id="descuentoGeneral">
                                    </div>
                                    <div class="col">
                                        <label for="">Total</label>
                                        <input type="number" name="total" class="form-control" step="any" id="totalGeneral" readonly value="<?php echo e($total); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Transferir</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>


        <div class="modal fade" id="carritoCompraModal" tabindex="-1" aria-labelledby="addInventario" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="<?php echo e(route('concluir.compra')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">Carrito de Compra</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Producto</th>
                                            <th>Precio</th>
                                            <th>Cantidad</th>
                                            <th>Sub Total</th>
                                            <th>Descuento %</th>
                                            <th>Total</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tablita">
                                        <?php
                                            $total = 0;
                                        ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $carritoCompras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($item->id); ?></td>
                                                <td><?php echo e($item->inventario[0]->name); ?></td>
                                                <td>$<?php echo e($item->inventario[0]->price); ?></td>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td>$<?php echo e($item->subtotal); ?></td>
                                                <td><?php echo e($item->discount); ?>%</td>
                                                <td>$<?php echo e($item->total); ?></td>
                                                <td>
                                                    <button class="btn btn-outline-danger" type="submit"><i class="bi bi-trash-fill"></i></button>
                                                </td>
                                            </tr>
                                            <?php
                                                $total += $item->total;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="container">
                                <div class="row">
                                    <div class="col">
                                        <label for="">Sucursal</label>
                                        <select name="office_id" id="" class="form-control" required>
                                            <option selected value="<?php echo e(Auth::user()->branch_office_id); ?>"><?php echo e(Auth::user()->branchOffice->name); ?></option>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <label for="">Tipo Pago</label>
                                        <select name="type" id="type" class="form-control" required>
                                            <option value="">--Seleccionar--</option>
                                            <option value="Efectivo">Efectivo</option>
                                            <option value="Tarjeta">Tarjeta</option>
                                            <option value="Transferencia">Transferencia</option>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <label for="">Sub Total</label>
                                        <input type="number" name="subtotal" class="form-control" step="any" id="subtotalGeneralCompra" readonly value="<?php echo e($total); ?>">
                                    </div>
                                    <div class="col">
                                        <label for="">Descuento %</label>
                                        <input type="number" name="discount" value="0" min="0" class="form-control" step="any" max="100" id="descuentoGeneralCompra">
                                    </div>
                                    <div class="col">
                                        <label for="">Total</label>
                                        <input type="number" name="total" class="form-control" step="any" id="totalGeneralCompra" readonly value="<?php echo e($total); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Comprar</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>

        <script>
            $(document).ready(function () {
                $('.cantidad').on('change',function(){
                    var id = $(this).data('id');
                    var precio = $('#price'+id).val();
                    var cantidad = $(this).val();
                    var subtotal = cantidad * precio;
                    var descuento = $('#descuento'+id).val();
                    $('#subtotal'+id).val(subtotal);
                    var porcentaje = descuento/100;
                    var total = subtotal - (subtotal * porcentaje);
                    $('#total'+id).val(total);
                });

                $('.descuento').on('change',function(){
                    var id = $(this).data('id');
                    var descuento = $(this).val();
                    var subtotal = $('#subtotal'+id).val();
                    var porcentaje = descuento/100;
                    var total = subtotal - (subtotal * porcentaje);
                    $('#total'+id).val(total);
                });

                $('.descuento').keyup(function (e) {
                    var id = $(this).data('id');
                    var descuento = $(this).val();
                    var subtotal = $('#subtotal'+id).val();
                    var porcentaje = descuento/100;
                    var total = subtotal - (subtotal * porcentaje);
                    $('#total'+id).val(total);
                });

                $.get('/getCarrito',function(data){

                });

                $('#descuentoGeneral').keyup(function (e) {
                    var descuento = $(this).val();
                    var porcentaje = descuento/100;
                    var subtotal = $('#subtotalGeneral').val();
                    var total = subtotal - (subtotal * porcentaje);
                    $('#totalGeneral').val(total.toFixed(2));
                });

                $('#descuentoGeneral').on('change',function (){
                    var descuento = $(this).val();
                    var porcentaje = descuento/100;
                    var subtotal = $('#subtotalGeneral').val();
                    var total = subtotal - (subtotal * porcentaje);
                    $('#totalGeneral').val(total.toFixed(2));
                });



                $('.cantidadCompra').on('change',function(){
                    var id = $(this).data('id');
                    var precio = $('#cost'+id).val();
                    var cantidad = $(this).val();
                    var subtotal = cantidad * precio;
                    var descuento = $('#descuentoCompra'+id).val();
                    $('#subtotalCompra'+id).val(subtotal);
                    var porcentaje = descuento/100;
                    var total = subtotal - (subtotal * porcentaje);
                    $('#totalCompra'+id).val(total);
                });

                $('.descuentoCompra').on('change',function(){
                    var id = $(this).data('id');
                    var descuento = $(this).val();
                    var subtotal = $('#subtotalCompra'+id).val();
                    var porcentaje = descuento/100;
                    var total = subtotal - (subtotal * porcentaje);
                    $('#totalCompra'+id).val(total);
                });

                $('.descuentoCompra').keyup(function (e) {
                    var id = $(this).data('id');
                    var descuento = $(this).val();
                    var subtotal = $('#subtotalCompra'+id).val();
                    var porcentaje = descuento/100;
                    var total = subtotal - (subtotal * porcentaje);
                    $('#totalCompra'+id).val(total);
                });


                $('#descuentoGeneralCompra').keyup(function (e) {
                    var descuento = $(this).val();
                    var porcentaje = descuento/100;
                    var subtotal = $('#subtotalGeneralCompra').val();
                    var total = subtotal - (subtotal * porcentaje);
                    $('#totalGeneralCompra').val(total.toFixed(2));
                });

                $('#descuentoGeneralCompra').on('change',function (){
                    var descuento = $(this).val();
                    var porcentaje = descuento/100;
                    var subtotal = $('#subtotalGeneralCompra').val();
                    var total = subtotal - (subtotal * porcentaje);
                    $('#totalGeneralCompra').val(total.toFixed(2));
                });


            });
        </script>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\insadminv2-tjgreen\resources\views/warehouse/index.blade.php ENDPATH**/ ?>