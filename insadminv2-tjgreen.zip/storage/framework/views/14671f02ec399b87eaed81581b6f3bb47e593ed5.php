<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="modal fade" id="userModalEdit" tabindex="-1" role="dialog" aria-labelledby="userModalEditLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="userModalEditLabel">Editar monto inicial</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="myFormEdit" action="/initialCash" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>                        
                        <div class="form-group my-3 mx-3">
                            <label for="name">Monto</label>
                            <input type="number" min=0 class="form-control" name="amount" id="amount" value=""placeholder="Monto inicial" required />
                        </div>                                   
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">CANCELAR</button>
                            <button type="submit" class="btn btn-primary">GUARDAR</button>
                        </div>
                    </form>
                </div>           
            </div>
        </div>
    </div>
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <?php echo e($error); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="card p-4">
        <?php if(isset($flag)): ?>
            <div class="mb-2">
                <h5>Monto inicial</h5>
                <h6 style="color: red;">*Este valor será el dinero inicial al abrir todas las cajas*</h6>
            </div>
            <ul class="list-group">
            <?php if(count($amount)==0): ?>
                <li class="list-group-item text-center">
                    Aún no ha definido un monto inicial
                </li>
            <?php endif; ?>
            <?php $__currentLoopData = $amount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                <div class="row">
                    <div class="col-md-10">
                    <?php echo e($item->amount); ?>

                    </div>
                    <div class="col-md-2 d-flex justify-content-center">
                        <button onclick="llenar(<?php echo e($item); ?>)" type="button" class="btn btn-outline-primary btn-sm" data-toggle="modal"  data-target="#userModalEdit">
                        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/>
                        </svg>  
                            <small>EDITAR</small>
                        </button>
                    </div>
                </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <div class="mb-2">
                <h5>Seleccionar monto inicial</h5>
                <h6 style="color: red;">*Este valor será el dinero inicial al abrir todas las cajas*</h6>
            </div>
            <form action="initialCash" method="POST">
                <?php echo csrf_field(); ?>
                <div class="input-group my-3">
                    <div class="input-group-prepend">
                    <span class="input-group-text">Monto inicial</span>
                    </div>
                    <input type="number" class="form-control" name="amount" required>
                    <div class="input-group-append">
                        <button class="btn btn-outline-primary" type="submit" id="button-addon">AGREGAR</button>
                    </div>
                </div>  
            </form>
        <?php endif; ?>   
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    function llenar(item){        
        document.getElementById("myFormEdit").action = "/initialCash/"+item.id;        
        
        document.getElementById('amount').value = item.amount
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\insadminv2-tjgreen\resources\views/layouts/InitialCash.blade.php ENDPATH**/ ?>