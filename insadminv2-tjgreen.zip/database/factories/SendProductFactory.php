<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SendProduct;
use Faker\Generator as Faker;

$factory->define(SendProduct::class, function (Faker $faker) {
    return [
        //
    ];
});
