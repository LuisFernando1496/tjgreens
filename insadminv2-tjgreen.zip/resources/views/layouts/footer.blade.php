<div>
    <footer class="footer">
        <div class="container-fluid">
            <nav class="pull-left">
                <ul>
                </ul>
            </nav>
            <div class="copyright pull-right">
                &copy; <script>document.write(new Date().getFullYear())</script>, Inusual Admin Alpha 2.0
                <img src="{{asset('alien.jpg')}}" width="20" height="20" alt=""> Por <a target="_blanck" href="http://inusualsoft.com/" style="">Inusual Software</a>
            </div>
        </div>
    </footer>
</div>